
# Build package 
1. open conda terminal
2. access the folder of package (cd)
3. activate virtual environment
4. build package
    python setup.py sdist
5. install package for environment
    pip install ./... 
