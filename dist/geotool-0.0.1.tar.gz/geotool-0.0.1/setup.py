from setuptools import setup, find_packages

setup(
    name='geotool',
    version='0.0.1',
    description='',
    packages=find_packages()
)

